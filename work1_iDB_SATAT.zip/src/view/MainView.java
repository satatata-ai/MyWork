package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import bean.StatementType;
import create.FileMgr;
import utils.Block;
import utils.Page;
import utils.User;

public class MainView extends JFrame {
	private static final long serialVersionUID = 1L;

	User u1 = new User();
	JPanel pan = new JPanel(null);
	JLabel greet = new JLabel("欢迎使用iDB");
	JLabel SQLText = new JLabel("请输入SQL语句");
	JTextField SQLState = new JTextField();
	JTextArea textArea = new JTextArea();
	JTextArea log = new JTextArea();
	Font font1 = new Font("Yahei", Font.BOLD, 48);
	Font font2 = new Font("宋体", Font.BOLD, 20);
	JScrollPane jsp = new JScrollPane(textArea, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
			JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JScrollPane jspLog = new JScrollPane(log, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
			JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

	public MainView(User u1) {
		this.u1 = u1;
		this.init();
//		System.out.println(u1.toString());
	}

	public void init() {
		BufferedImage iconImg = null;
		try {
			iconImg = ImageIO.read(new File("img/qq1.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.setSize(600, 500);
		this.setResizable(false);
		this.setTitle("欢迎使用iDB的GUI");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);

		this.setIconImage(iconImg);
		this.addPart();
		this.listen();
		this.pack();
		this.setVisible(true);
	}

	public void addPart() {

		pan.setPreferredSize(new Dimension(600, 500));
		pan.setBackground(new Color((int) (Math.random() * 256), // 背景为随机颜色
				(int) (Math.random() * 256), (int) (Math.random() * 256)));
		greet.setBounds(150, 15, 450, 45);
		greet.setFont(font1);
		pan.add(greet);
		SQLText.setBounds(25, 90, 150, 30);
		SQLText.setFont(font2);
		pan.add(SQLText);
		SQLState.setBounds(180, 90, 350, 30);
		pan.add(SQLState);
		jsp.setBounds(30, 150, 540, 280);
		pan.add(jsp);
		jspLog.setBounds(30, 440, 540, 50);
		pan.add(jspLog);
		this.add(pan);
	}

	public void listen() {
	
		SQLState.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				int keyCode = e.getKeyCode();
				if (keyCode == KeyEvent.VK_ENTER) {
//					textArea.append(SQLState.getText() + "\r\n");
					String sqlState = SQLState.getText();
					sqlState = sqlState.toLowerCase();
					User u2 = new StatementType().getStatementType(sqlState, u1);
					String logs = u2.getLogs();
					if(logs.contains("Error")) {
						textArea.setText(logs.split("~")[0]);
						log.setText(logs.split("~")[1]);
					}else if(logs.contains("OK")) {
						if(sqlState.contains("select")) {
							textArea.setText(u2.getSelectResult());
						}else {
							textArea.setText(logs.split("~")[0]);
						}
						log.setText(logs.split("~")[1]);
					}
					
					if(!("".equals(sqlState.split(" ")[0]))) {
//						result = new StatementType().get;
					}
					//向当前日志写入内容
					System.out.println(u1.getLogFileName());
					
					if(u1.getUseDB()!=null && u1.getLogFileName()!=null) {
						//勉强算是用到了缓冲区，但没用到缓冲区的真正作用，可以添加块
						int npos = Page.maxLength( u1.getLogs().length());
						byte[] b = new byte[npos * 2];// 记录的总长度，4字节是整数长度
						String logPath = "D:\\iDBLib\\"+u1.getUseDB()+"\\logs";
						FileMgr fLog = new FileMgr(logPath+"\\"+u1.getLogFileName(), 256);
						// 字节数组b,是内存页的实际存储空间
						Page p = new Page(b); // 固定缓冲区大小
						Block blk = fLog.append("\\logs"+"\\"+u1.getLogFileName());  //添加块，即往后追加内容
						p.setString(0, u1.getLogs());// 把该条记录的字符串按位置startpos写入内存页
						fLog.write(blk, p);
						try {
							fLog.getF().close();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
				}
			}
		});
	}
}
