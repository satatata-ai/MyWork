package view;
/**
 * 低仿 mysql,page编码 UTF-8
 */
public class Start {
	public static void main(String[] args) {
		Login lg = new Login();
		lg.init();
	}
}
