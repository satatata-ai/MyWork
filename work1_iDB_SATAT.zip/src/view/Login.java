package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import utils.User;

public class Login extends JFrame {
	private static final long serialVersionUID = 1L;
	// 背景
	BufferedImage LoginImg;
	BufferedImage registerImg;
	BufferedImage iconImg;

	JPanel pan = new JPanel(null); // 空布局（绝对定位布局） 改用自己写面板

	// 标签
	JLabel title = new JLabel("欢迎登录iDB");
	JLabel username = new JLabel("用户名：");
	JLabel password = new JLabel(" 密码：");
	// 文本框与密码框
	JTextField usernameText = new JTextField();
	JPasswordField passwordText = new JPasswordField();
	// 字体
	Font font1 = new Font("微软雅黑", Font.BOLD, 18);
	Font font2 = new Font("微软雅黑", Font.BOLD, 20);
	Font font3 = new Font("楷体", Font.BOLD, 20);
	Font fontx = new Font("Yahei", Font.BOLD, 48);
	// 两个按钮
	JButton enter = new JButton();
	JButton register = new JButton();

	// 初始化
	public void init() {
		try { // 注意文件路径
			iconImg = ImageIO.read(new File("img/qq1.png"));
			LoginImg = ImageIO.read(new File("img/login.png"));
			registerImg = ImageIO.read(new File("img/register.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}

		this.setSize(600, 500);// 面板大小
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false); // 大小不可变
		this.setLocationRelativeTo(null);// 屏幕居中
		this.addPart();
		this.addLis();
		this.setTitle("欢迎使用iDB，请登录！");
		this.setIconImage(iconImg);
		this.pack();
		this.setVisible(true);

	}

	// 添加组件
	public void addPart() {
		pan.setPreferredSize(new Dimension(600, 500));

		// 登录
		pan.add(title);// 添加
		title.setBounds(150, 35, 450, 45);
		title.setFont(fontx);// 设置字体
//		title.setForeground(Color.DARK_GRAY);//深灰色 

		// 第一行:标签+文本框
		pan.add(username);
		username.setBounds(70, 160, 110, 55);
		username.setFont(font2);
		username.setForeground(Color.black);

		pan.add(usernameText);
		usernameText.setBounds(180, 160, 320, 45);
		usernameText.setFont(font3);
		usernameText.setOpaque(false);

		// 第二行 ：标签+密码框
		pan.add(password);
		password.setBounds(70, 265, 110, 45);
		password.setFont(font2);
		password.setForeground(Color.black);

		pan.add(passwordText);
		passwordText.setBounds(180, 265, 320, 45);
		passwordText.setFont(font1);
		passwordText.setEchoChar('*');
		passwordText.setOpaque(false);

		// 两个按钮
		pan.add(enter);
		enter.setBounds(90, 415, 159, 44);
		enter.setIcon(new ImageIcon(LoginImg));
		enter.setMargin(new Insets(0, 0, 0, 0));// 设置边距
		enter.setBorderPainted(false);// 不绘制边框
		enter.setContentAreaFilled(false);// 除去默认的背景填充

		pan.add(register);
		register.setBounds(350, 415, 159, 44);
		register.setIcon(new ImageIcon(registerImg));
		register.setMargin(new Insets(0, 0, 0, 0));// 设置边距
		register.setBorderPainted(false);// 不绘制边框
		register.setContentAreaFilled(false);// 除去默认的背景填充
		this.add(pan);
	}

	// 添加事件监听
	public void addLis() {
		// 匿名内部类 （匿名接口实现类） e-> 拉姆达表达式
		// 匿名内部类写外部这个类的当前对象，需要带上外部类的类名，再写this
		enter.addActionListener(e -> {
			String user = usernameText.getText();
			String psw = new String(passwordText.getPassword());

			BufferedReader br = null;
			String thisLine;
			String[] oneUser;
			boolean flag = false;
			User u1 = new User();
			try {
				br = new BufferedReader(new FileReader("./config/user"));
				while ((thisLine = br.readLine()) != null) {
					oneUser = thisLine.split("-");
					if (oneUser[0].equals(user) && oneUser[1].equals(psw)) {
						flag = true;
						u1.setUser(user);
						u1.setPassword(psw);
						u1.setLevel(Integer.valueOf(oneUser[2]));
						u1 = getPermission(u1, oneUser[3]);
						if ("1".equals(oneUser[2])) {
							JOptionPane.showMessageDialog(pan, "管理员: " + user + " 登录成功\n即将跳转...");
						} else {
							JOptionPane.showMessageDialog(pan, "用户: " + user + " 登录成功\n即将跳转...");
						}
						Login.this.setVisible(false);// 窗口隐藏（并没有关闭!）
						new MainView(u1);
					}
				}
				if (!flag) {
					JOptionPane.showMessageDialog(pan, "用户名或密码错误");
					usernameText.setText("");
					passwordText.setText("");
				}
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			} catch (IOException e2) {
				e2.printStackTrace();
			}

		});
		register.addActionListener(e -> {
			String user = usernameText.getText();
			String psw = new String(passwordText.getPassword());// password是char型数组
			// 注冊：输入 用户名和密码 到数据库 查该用户名的所有信息 得到对象
			if (user != null || psw != null) {
				JOptionPane.showMessageDialog(pan, "暂时不支持注册功能！");
			}

		});
		usernameText.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				int keycode = e.getKeyCode();
				if (keycode == KeyEvent.VK_ENTER) {
					passwordText.requestFocus();
				}
			}
		});
	}
	
	private User  getPermission(User u1,String permission) {
		String[] split = permission.split(",");
		for (String string : split) {
			if("Select".equals(string)) {
				u1.setSelect(true);
			}else if("Create".equals(string)) {
				u1.setCreate(true);
			}else if("Insert".equals(string)) {
				u1.setInsert(true);;
			}else if("Update".equals(string)) {
				u1.setUpdate(true);
			}else if("Delete".equals(string)) {
				u1.setDelete(true);
			}
		}
		return u1;
	}
}
